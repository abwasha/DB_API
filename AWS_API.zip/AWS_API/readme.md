Step 1: install python version 3.9

Step 2: Install requirements
pip install -r requirements.txt

Step 3:
python app.py

Step 4: In a seperate command prompt run the folowing command one after another
 - python
 - from app import db
 - db.create_all()
 - quit()

 Step 5: In postman use the following end point for CRUD operations

 - Get All Users
 http://127.0.0.1:5000/api/users

 - Get User by Id
 http://127.0.0.1:5000/api/users?id=2


 - Insert a record with following body
http://127.0.0.1:5000/api/users/add
 {
    "username":"A1",
    "salary":1000,
    "first_name":"Abdul",
    "last_name":"Shariff",
    "age":35
}

- Update a record with following body
http://127.0.0.1:5000/api/users/modify?id=1
 {
    "username":"A1",
    "salary":5000,
    "first_name":"Abdul Wahab",
    "last_name":"Shariff",
    "age":33
}

- Delete a record
http://127.0.0.1:5000/api/users/delete?id=1
