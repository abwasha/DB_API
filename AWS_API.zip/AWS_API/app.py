from sqlite3 import IntegrityError
from flask import Flask, request, jsonify
from flask_restful import Resource, Api
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm.exc import UnmappedInstanceError

# Step 1 :Create a Flask application object and set the URI for the database to use.
# Step 2 : Create a class of SQLAlchemy to specify datatype and their size
# Step 3 : Create a class of Marshmallow to serialize and format the schema
# Step 4 : Create 2 objects to fetch a single user or multipleusers
# Step 5 : Create a class to handle the CRUD operations

app = Flask(__name__)
api = Api(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db=SQLAlchemy(app)
ma=Marshmallow(app)

class User_Model(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(32), unique=True)
    salary = db.Column(db.Integer)
    first_name = db.Column(db.String(32))
    last_name = db.Column(db.String(32))
    age = db.Column(db.Integer)



    def __init__(self, username, salary, first_name, last_name, age):
        self.username = username
        self.salary = salary
        self.first_name = first_name
        self.last_name = last_name
        self.age = age 

class User_Schema(ma.Schema):
    class Meta: 
        fields = ('id', 'username', 'salary', 'first_name', 'last_name', 'age')

user_schema = User_Schema()
users_schema = User_Schema(many=True)



class UserManager(Resource):
    @staticmethod
    @app.route('/api/users',methods=['GET'])
    def get():
        try: id = request.args['id']
        except Exception as _: id = None

        if not id:
            users = User_Model.query.all()
            return jsonify(users_schema.dump(users))
        user = User_Model.query.get(id)
        return jsonify(user_schema.dump(user))

    @staticmethod
    @app.route('/api/users/add',methods=['POST'])
    def post():
        try:
            username = request.json['username']
            salary = request.json['salary']
            first_name = request.json['first_name']
            last_name = request.json['last_name']
            age = request.json['age']

            user = User_Model(username, salary, first_name, last_name, age)
            db.session.add(user)
            db.session.commit()
            return jsonify({
                'Message': f'User {first_name} {last_name} inserted.'
            }),201

        except IntegrityError:
            db.session.rollback()
            return jsonify({
                'Message': f'Username {username} already exists!!!'
            }),500


    @staticmethod
    @app.route('/api/users/modify',methods=['PUT'])
    def put():
        try: id = request.args['id']
        except Exception as _: id = None
        if not id:
            return jsonify({ 'Message': 'Must provide a valid existing user ID' })
        
        try:
            user = User_Model.query.get(id)

            username = request.json['username']
            salary = request.json['salary']
            first_name = request.json['first_name']
            last_name = request.json['last_name']
            age = request.json['age']

            user.username = username 
            user.salary = salary 
            user.first_name = first_name 
            user.last_name = last_name
            user.age = age 

            db.session.commit()
            return jsonify({
                'Message': f'User {first_name} {last_name} altered.'
            }),201
        except AttributeError:
            db.session.rollback()
            return jsonify({
                'Message': f'User ID {id} does not exist!!!'
            }),500

    @staticmethod
    @app.route('/api/users/delete',methods=['DELETE'])
    def delete():
        try: id = request.args['id']
        except Exception as _: id = None
        if not id:
            return jsonify({ 'Message': 'Must provide a valid existing user ID' })
        
        try:
            user = User_Model.query.get(id)
            print(user)

            db.session.delete(user)
            db.session.commit()

            return jsonify({
            'Message': f'User ID {id} deleted.'
        })

        except UnmappedInstanceError:
            db.session.rollback()
            return jsonify({
                'Message': f'User ID {id} does not exist!!!'
            }),500


if __name__ == '__main__':
    app.run(debug=True)