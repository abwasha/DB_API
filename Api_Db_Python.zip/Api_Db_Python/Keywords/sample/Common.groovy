
package sample

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS

import groovy.json.JsonSlurper

public class Common {

	public static JsonSlurper jsonSlurper = new JsonSlurper()


	@Keyword
	def static findUserById(int id) {
		def response =WS.sendRequest(findTestObject('GET Single User'))

		WS.verifyResponseStatusCode(response, 200)

		def Map jsonResponse = jsonSlurper.parseText(response.getResponseText())
		return jsonResponse
	}

	@Keyword
	def static findAllUsers() {
		def response=WS.sendRequest(findTestObject('GET all users'))


		WS.verifyResponseStatusCode(response, 200)

		def jsonResponse = jsonSlurper.parseText(response.getResponseText())
		return jsonResponse
	}
}
