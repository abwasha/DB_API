import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import org.json.JSONObject as JSONObject
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import groovy.json.JsonSlurper as JsonSlurper
import org.json.JSONException as JSONException
import com.kms.katalon.core.webservice.verification.WSResponseManager as WSResponseManager

KeywordUtil.logInfo('This test case is to modify a unique valid user in the Db and the return response to be 201 Ok, otherwise fail the test case and return the message')

JsonSlurper slurper = new JsonSlurper()

String myJSON = '{ "username": "A_Modified", "salary": 10, "first_name": "A_Modified", "last_name": "S_Modified", "age": 22 }'

KeywordUtil.logInfo(myJSON)

JSONObject jsonObject = new JSONObject(myJSON)

response = WS.sendRequest(findTestObject('Object Repository/PUT modify a user', [('req_body') : jsonObject, ('id') : GlobalVariable.globalId]))

int result = response.getStatusCode()

KeywordUtil.logInfo('-------' + result)

if (result != 201) {
    KeywordUtil.markFailedAndStop(response.getResponseText())
} else {
    KeywordUtil.markPassed(response.getResponseText())
}
