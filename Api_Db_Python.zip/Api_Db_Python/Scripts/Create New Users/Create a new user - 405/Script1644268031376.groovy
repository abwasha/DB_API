import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import org.json.JSONObject

import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS

import groovy.json.JsonSlurper
import org.json.JSONException;
import org.json.JSONObject;
import com.kms.katalon.core.webservice.verification.WSResponseManager as WSResponseManager
import groovy.json.JsonSlurper as JsonSlurper

KeywordUtil.logInfo('This test case is to insert a unique valid user with PUT in the Db and the return response to be 405')

JsonSlurper slurper = new JsonSlurper()

Random random = new Random();
int rand = random.nextInt(50);

String temp="A1_"+rand

String myJSON = "{ \"username\": $temp,\"salary\": 10, \"first_name\": \"Abdul\", \"last_name\": \"Shariff\", \"age\": $rand }";

KeywordUtil.logInfo(myJSON)

JSONObject jsonObject = new JSONObject(myJSON);

response = WS.sendRequest(findTestObject("Object Repository/PUT a new user",[('req_body'):jsonObject]))

int result=response.getStatusCode()

KeywordUtil.logInfo("-------"+result)

jsonResponse = slurper.parseText(response.getResponseBodyContent())

if(result==405)
	KeywordUtil.markFailedAndStop(jsonResponse.toString())


