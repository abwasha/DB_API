import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import org.json.JSONObject

import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS

import groovy.json.JsonSlurper
import org.json.JSONException;
import org.json.JSONObject;
import com.kms.katalon.core.webservice.verification.WSResponseManager as WSResponseManager
import groovy.json.JsonSlurper as JsonSlurper

KeywordUtil.logInfo('This test case is to delete a unique valid user with other that DELETE in the Db and the return response to be 405')

JsonSlurper slurper = new JsonSlurper()

String myJSON = "{ \"username\": \"A5\", \"salary\": 10, \"first_name\": \"AW\", \"last_name\": \"Srt\", \"age\": 22 }";

KeywordUtil.logInfo(myJSON)

JSONObject jsonObject = new JSONObject(myJSON);

response = WS.sendRequest(findTestObject("Object Repository/DELETE a user - 405",[('req_body'):jsonObject]))

int result=response.getStatusCode()

KeywordUtil.logInfo("-------"+result)

if(result==405)
	KeywordUtil.markPassed(response.getResponseText())


