<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>All Test Cases</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>df88b384-4db8-4c82-b255-0afa0fd22006</testSuiteGuid>
   <testCaseLink>
      <guid>e7e4750b-7296-4ff6-83b3-891c5adb7acb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Create New Users/Create a new user</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7a84825b-cb0d-42d5-98cc-d59229eb047a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Create New Users/Create a new user</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>685e1ac8-bf62-43f7-8ad6-bc498da2d477</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Create New Users/Create a new user - 405</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e22b9521-34d7-4347-a47b-e745beee7b22</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Get User Test Cases/Find All Users</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0e9bbffb-468f-4e65-8b26-c55ce80b828f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Get User Test Cases/Find InValid User</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7b0fa490-627f-4377-9ba1-836cafda9790</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Get User Test Cases/Find Single Valid User</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>cc775fa3-93ec-423a-9aeb-63acfde1dd60</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Modify Existing Users/Modify a user - 405</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>15790530-a49f-4b85-8ddb-2da2501e59ab</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Modify Existing Users/Modify a user</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>48756f9b-e8ae-4f86-8cb2-8b839eaf06f1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Delete Existing Users/Delete a user</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>40e621c5-c08d-40ee-8c75-89ff7e7d0b13</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Delete Existing Users/Delete a user - 405</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
